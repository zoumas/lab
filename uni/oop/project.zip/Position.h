#ifndef POSITION_H
#define POSITION_H
struct Position {
	int y;
	int x;

	Position(): y(-1), x(-1) {}
	Position(const int y, const int x): y(y), x(x) {}
};
#endif
