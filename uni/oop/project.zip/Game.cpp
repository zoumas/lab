#include "Game.h"
#include <cstdlib>
#include <ctime>
#include <queue>
#include <algorithm>

#define EXIT_ICON ACS_DIAMOND
#define ESCAPE 27

Game::Game(const char* filename) 
: board(new Board(filename)), game_over(false), teleport_counter(0) 
{
	// Seed the random number generator 
	// for the generation of empty coordinates
	srand(time(0));

	// Χρώματα
	init_pair(1, COLOR_GREEN, COLOR_BLACK);
	init_pair(2, COLOR_RED, COLOR_BLACK);
	
	teleport_limit = rand() % board->height() + 1;

	// Kλήρωση Τυχαίων Αρχικών Θέσεων, Εισαγωγή στον Λαβύρινθο
	int y, x;
	board->get_empty_coordinates(y, x);
	player = new Entity(y, x, 'L' | COLOR_PAIR(1)); // ΛΟΥΚΑΣ ΜΑΛΦΟΗΣ
	board->add(player);

	board->get_empty_coordinates(y, x);
	opp = new Entity(y, x, 'M' | COLOR_PAIR(2)); // ΜΠΑΜΠΗΣ ΠΟΤΕΡΙΔΗΣ
	board->add(opp);

	board->get_empty_coordinates(y, x);
	exit = new Entity(y, x, EXIT_ICON); // ΜΑΓΙΚΟ ΠΕΤΡΑΔΙ
	board->add(exit);
}

void Game::run() {
	for (;;) {
		chtype input(board->get_input());

		// Ο χρήστης μπορεί να τερματίσει το πρόγραμμα με τη χρήση του πλήκτρου “Escape”.
		if (input == ESCAPE) {
			return;
		}

		bool player_moved(handle_player(input));
		if (player_moved) {
			if (is_on_exit(player)) {
				return;
			}

			handle_opp();
			if (is_on_exit(opp)) {
				return;
			}

			handle_exit();
		}

		refresh();
	}
}

Game::~Game() {
	delete exit;
	delete opp;
	delete player;

	delete board;
}

bool Game::is_on_exit(Entity* e) {
	return (e->y() == exit->y() && e->x() == exit->x());
}

bool Game::is_on_exit(int y, int x) {
	return (y == exit->y() && x == exit->x());
}

// Ο παίκτης (Λουκάς Μαλφόης) ανταποκρίνεται στις εντολές του χρήστη.
// Άκυροι πληκτρισμοί και εντολές κίνησης προς τοίχο αγνοούνται από το πρόγραμμα.
bool Game::handle_player(chtype input)
{
	// Ακινησία
	if (input == ' ') {
		return true;
	}

	int y(player->y());
	int x(player->x());

	switch (input) {
	case KEY_UP:
		--y;
		break;
	case KEY_DOWN:
		++y;
		break;
	case KEY_LEFT:
		--x;
		break;
	case KEY_RIGHT:
		++x;
		break;
	default:
		return false;
	}

	if (is_valid_position(y, x) && is_passable_cell(y, x)) {
		board->move_entity_to(player, y, x);
		return true;
	}

	return false;
}

void Game::handle_opp() {
	Position next(get_next_move(Position(opp->y(), opp->x())));
	board->move_entity_to(opp, next.y, next.x);
}

void Game::handle_exit()
{
	if (!game_over) {
		++teleport_counter;
		if (teleport_counter == teleport_limit) {
			teleport_counter = 0;
			teleport_limit = rand() % board->width() + 1;

			teleport_exit();
		}
	}
}

void Game::teleport_exit() {
	int y,x;
	board->get_empty_coordinates(y, x);
	board->move_entity_to(exit, y, x);
}

void Game::redraw() {
	board->refresh();
}

bool Game::is_valid_position(int y, int x) {
	return (y >= 1 && y < board->height() && x >= 1 && x < board->width());
}

bool Game::is_passable_cell(int y, int x) {
	chtype ch = board->get_char_at(y, x);
	return (ch == ' ' || ch == exit->icon());
}

Position Game::get_next_move(Position start) {
	std::vector<Position> path(find_shortest_path_to_exit(start));
	if (path.size() > 1) {
		return path[1];
	}
	return start;
}

std::vector<Position> Game::find_shortest_path_to_exit(Position start) {
	const int width(board->width());
	const int height(board->height());

	std::vector<std::vector<bool>> visited(height, std::vector<bool>(width, false));
	std::vector<std::vector<Position>> parent(height, std::vector<Position>(width));

	std::queue<Position> q;
	q.push(start);
	visited[start.y][start.x] = true;

	const Position directions[4] = {
		{  0, -1},
		{  0,  1},
		{ -1,  0},
		{  1,  0},
	};

	while (!q.empty()) {
		Position current = q.front();
		q.pop();

		if (is_on_exit(current.y, current.x)) {
			break;
		}

		for (const Position& dir : directions) {
			Position next = {
				current.y + dir.y,
				current.x + dir.x,
			};

			if (!visited[next.y][next.x]
				&& is_valid_position(next.y, next.x)
				&& is_passable_cell(next.y, next.x)) {

				q.push(next);
				visited[next.y][next.x] = true;
				parent[next.y][next.x] = current;
			}
		}
	}

	if (!visited[exit->y()][exit->x()]) {
		return {};
	}

	std::vector<Position> path;
	Position current(exit->y(), exit->x());
	while (!(current.y == start.y && current.x == start.x)) {
		path.push_back(current);
		current = parent[current.y][current.x];
	}
	path.push_back(start);

	std::reverse(path.begin(), path.end());

	return path;
}
