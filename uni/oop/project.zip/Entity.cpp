#include "Entity.h"

Entity::Entity(const int y, const int x, const chtype icon) : position(y, x), _icon(icon) {}
Entity::~Entity() {}

const int& Entity::y() const { return position.y; }

void Entity::set_y(const int y) { position.y = y; }

const int& Entity::x() const { return position.x; }
void Entity::set_x(const int x) { position.x = x; }

const chtype& Entity::icon() const { return _icon; }
void Entity::set_icon(const chtype icon) { _icon = icon; }

void Entity::relocate(const int y, const int x)
{
	position.y = y;
	position.x = x;
}
