#ifndef ENTITY
#define ENTITY

#include <ncurses.h>
#include "Position.h"

// [MODEL]
class Entity {
protected:
	Position position;
	chtype _icon;
public:
	Entity(const int y, const int x, const chtype icon);
	virtual ~Entity();

	const int& y() const;
	void set_y(const int y);

	const int& x() const;
	void set_x(const int x);
	const chtype& icon() const;
	void set_icon(const chtype icon);

	void relocate(const int y, const int x);
};
#endif
