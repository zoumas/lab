#include "Board.h"
#include <cstdlib>
#include <fstream>
#include <vector>
#include <string>

Board::Board(const char *filename) {
	std::ifstream ifs(filename);
	if (!ifs.is_open()) {
		std::fprintf(stderr, "Error: Failed to open file: %s\n", filename);
		std::exit(1);
	}

	std::vector<std::string> maze;
	std::string line;
	while (std::getline(ifs, line)) {
		maze.push_back(line);
	}
	ifs.close();

	_height = maze.size();
	_width = maze[0].size();

	for (int y(0); y < _height; ++y) {
		if (maze[y].size() > _width) {
			std::fprintf(stderr, "Error: Uneven dimensions. The maze should be a bordered rectangle\n");
			std::exit(1);
		}

		for (int x(0); x < _width; ++x) {
			char ch(maze[y][x]);
			if ((ch != '.' && ch != '*')) {
				std::fprintf(stderr, "Error: %c is not a supported character in the maze's format\n", ch);
				std::exit(1);
			}
		}
	}

	// The map should be following the requirements after all those checks.
	initialize_ncurses();

	int max_y, max_x;
	getmaxyx(stdscr, max_y, max_x);
	int start_y((max_y - _height) / 2);
	int start_x((max_x - _width) / 2);

	_window = newwin(_height, _width, start_y, start_x);
	keypad(_window, true);
	wrefresh(stdscr);

	for (int y(0); y < _height; ++y) {
		for (int x(0); x < _width; ++x) {
			char ch(maze[y][x]);
			if (ch == '.') {
				add_at(y, x, ' ');
			} else {
				add_at(y, x, ACS_CKBOARD);
			}
		}
	}

	wrefresh(_window);
}

Board::~Board() {
	wclear(_window);
	werase(_window);
	delwin(_window);

	terminate_ncurses();
}

const WINDOW* Board::window() const { return _window; }
const int Board::height() const { return _height; }
const int Board::width() const { return _width; }

void Board::refresh() { wrefresh(_window); }

void Board::add_at(int y, int x, chtype icon) { mvwaddch(_window, y, x, icon); }
void Board::add(Entity *e) { add_at(e->y(), e->x(), e->icon()); }

void Board::add_empty(int y, int x) {
	add_at(y, x, ' ');
}

void Board::replace_with_empty(Entity* e) {
	add_empty(e->y(), e->x());
}

void Board::move_entity_to(Entity* e, int y, int x) {
	replace_with_empty(e);
	e->set_y(y);
	e->set_x(x);
	add(e);
}

chtype Board::get_input() const { 
	return wgetch(_window); 
}

chtype Board::get_char_at(int y, int x) const { 
	return mvwinch(_window, y, x); 
}

void Board::get_empty_coordinates(int &y, int &x) const {	
	while (get_char_at(y = std::rand() % _height, x = std::rand() % _width) != ' ');
}

void initialize_ncurses() {
	initscr();

	curs_set(0);
	noecho();
	cbreak();
	start_color();
}

void terminate_ncurses() {
	endwin();
}
