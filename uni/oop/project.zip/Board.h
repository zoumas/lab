#ifndef BOARD_H
#define BOARD_H

#include <ncurses.h>
#include "Entity.h"

class Board {
	WINDOW* _window;
	int _height;
	int _width;
public:
	Board(const char *filename);
	~Board();

	const WINDOW* window() const;
	const int height() const;
	const int width() const;

	void refresh();

	void add_at(int y, int x, chtype icon);
	void add(Entity*);
	void add_empty(int y, int x);
	void replace_with_empty(Entity*);
	void move_entity_to(Entity*, int y, int x);

	chtype get_char_at(int y, int x) const;
	chtype get_input() const;
	void get_empty_coordinates(int &y, int &x) const;
};

void initialize_ncurses();
void terminate_ncurses();
#endif
