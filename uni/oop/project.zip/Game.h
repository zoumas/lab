#ifndef GAME_H
#define GAME_H

#include "Board.h"
#include "Position.h"
#include <vector>

class Game {
	bool game_over;
	Board* board;

	Entity* player;
	Entity* opp;
	Entity* exit;

	int teleport_counter;
	int teleport_limit;
public:
	Game(const char *filename);
	~Game();

	void run();
private:
	void redraw();

	bool handle_player(chtype input);
	void handle_opp();
	void handle_exit();
	void teleport_exit();

	bool is_on_exit(Entity* d);
	bool is_on_exit(int y, int x);

	bool is_valid_position(int y, int x);
	bool is_passable_cell(int y, int x);

	Position get_next_move(Position start);
	std::vector<Position> find_shortest_path_to_exit(Position);
};
#endif
