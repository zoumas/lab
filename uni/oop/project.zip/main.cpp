#include "Game.h"
#include <iostream>

int main(int argc, char** argv) {
	if (argc != 2) {
		std::cerr << "Usage: " << argv[0] << " maze\n" 
			<< "Where maze, is the file that describes the Maze\n";
		return 1;
	}

	Game* game(new Game(argv[1]));
	game->run();
	delete game;
}
