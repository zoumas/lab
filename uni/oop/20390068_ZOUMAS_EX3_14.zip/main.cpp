#include "Student.h"
#include <iostream>
#include <cassert>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <sstream>

void run_tests();

int main(int argc, char** argv)
{
	run_tests();

	{
		auto c(std::make_shared<Course>("ICE-1004", "Προγραμματισμός Υπολογιστών", 6, Semester::Winter));
		auto cpp(std::make_shared<Course>("ICE-2004", "Αντικειμενοστρεφής Προγραμματισμός", 6, Semester::Spring));
		auto ds(std::make_shared<Course>("ICE-3003", "Δομές Δεδομένων", 5, Semester::Winter));
		auto networks(std::make_shared<Course>("ICE-3004", "Δίκτυα Υπολογιστών", 4, Semester::Winter));
		auto arch(std::make_shared<Course>("ICE-3006", "Αρχιτεκτονική Υπολογιστών", 5, Semester::Winter));
		auto java(std::make_shared<Course>("ICE-4004", "Μεθοδολογίες Ανάπτυξης Εφαρμογών", 5, Semester::Spring));
		auto db(std::make_shared<Course>("ICE-5001", "Βάσεις Δεδομένων", 4, Semester::Winter));

		Student hz("20390068", "ΗΛΙΑΣ ΖΟΥΜΑΣ", 6);
		hz += cpp;

		Student babis("20680039", "ΜΠΑΜΠΗΣ ΠΟΤΕΡΙΔΗΣ");
		try {
			babis.serialize_to_csv("babis.csv");
		} catch (std::ios_base::failure const& ex) {
			std::cerr << ex.what() << '\n';
			return 1;
		}

		hz.add_passed_course(c, 5.8f);
		hz.add_passed_course(ds, 6.0f);
		hz.add_passed_course(networks, 9.0f);
		hz.add_passed_course(arch, 7.5f);
		hz.add_passed_course(java, 6.0f);
		hz.add_passed_course(db, 7.5f);

		try {
			hz.serialize_to_csv("hz.csv");
		} catch (std::ios_base::failure const& ex) {
			std::cerr << ex.what() << '\n';
			return 1;
		}
	}

	try {
		std::cout << "Φοιτητής από CSV αρχείο\n\n";
	
		Student* deserialized_student(Student::deserialize_from_csv("hz.csv"));
		std::cout << *deserialized_student << "\n\n";
		delete deserialized_student;
	} catch (std::ios_base::failure const& ex){
		std::cerr << ex.what() << '\n';
		return 1;
	}


// Και άλλα Exceptions
	try {
		Student except(0, "Exception in Constructor");
	} catch (std::invalid_argument const& ex) {
		std::cerr << ex.what() << '\n';
	}

	try {
		Student except("123", "Exception in Setter");
		except.set_id(0);
	} catch (std::invalid_argument const& ex) {
		std::cerr << ex.what() << '\n';
	}
}

void test_course_object_creation();
void test_student_comparison_operators();
void test_exercise_2_requirements();

void run_tests()
{
	test_exercise_2_requirements();
	test_course_object_creation();
}

void test_course_object_creation()
{
	std::ofstream of("courses.csv");
	if (!of.is_open()) {
		std::exit(1);
	}

	Course c("ICE-1004", "Προγραμματισμός Υπολογιστών", 6, Semester::Winter);
	Course cpp("ICE-2004", "Αντικειμενοστρεφής Προγραμματισμός", 6, Semester::Spring);
	Course ds("ICE-3003", "Δομές Δεδομένων", 5, Semester::Winter);
	Course networks("ICE-3004", "Δίκτυα Υπολογιστών", 4, Semester::Winter);
	Course arch("ICE-3006", "Αρχιτεκτονική Υπολογιστών", 5, Semester::Winter);
	Course java("ICE-4004", "Μεθοδολογίες Ανάπτυξης Εφαρμογών", 5, Semester::Spring);
	Course db("ICE-5001", "Βάσεις Δεδομένων", 4, Semester::Winter);

	of << c << '\n';
	of << cpp << '\n';
	of << ds << '\n';
	of << networks << '\n';
	of << arch << '\n';
	of << java << '\n';
	of << db << '\n';

	of.close();
}

void test_student_comparison_operators()
{
	Student tmp("0", "tmp");
	Student another("1", "another", 2);

	assert(tmp.get_current_semester() == 1);
	assert(another.get_current_semester() == 2);

	assert((tmp == another) == false);
	assert((tmp != another) == true);
	assert((tmp < another) == true);
	assert((tmp <= another) == true);
	assert((tmp > another) == false);
	assert((tmp >= another) == false);

}

// Ελέγχει την ορθή κατασκευή αντικειμένων τύπου Student.
// Γράφει μία αναφορά (log) σε αρχείο
void test_student_object_creation();

// Ελέγχει την ορθή λειτουργία των υπερφορτωμένων τελεστών
// που επενεργούν στο τρέχον εξάμηνο ενός Φοιτητή.
void test_student_overloaded_operators();

void test_exercise_2_requirements()
{
	test_student_object_creation();
}

void test_student_object_creation()
{
	std::ofstream of("tests_log.txt");
	if (!of.is_open()) {
		std::exit(1);
	}

	of << "# Κατασκευή Φοιτητή με όλα τα χαρακτηριστικά\n\n";
	Student hz("20390068", "ΗΛΙΑΣ ΖΟΥΜΑΣ", 6);
	of << "hz:\n" << hz << "\n\n";


	of << "# Κατασκευή Φοιτητή ορίζοντας ΑΜ και Ονοματεπώνυμο.";
	of << " Το τρέχον εξάμηνο είναι 1\n\n";
	Student loukas("20680039", "Λουκάς Μαλφόης");
	of << "loukas:\n" << loukas << "\n\n";
	assert(loukas.get_current_semester() == 1);


	of << "# Κατασκευή Φοιτητή ορίζοντας σε όλα τα χαρακτηριστικά ως τιμές τις τιμές των χαρακτηριστικών ενός άλλου “Φοιτητή”\n\n";
	Student babis(loukas);
	of << "babis(loukas):\n" << babis << "\n\n";

	of << "# Επίδειξη των Setters\n\n";
	babis.set_id("20006839");
	babis.set_fullname("Μπάμπης Ποτερίδης");
	babis.set_current_semester(2);
	of << "babis:\n" << babis << "\n\n";


	of << "# Επίδειξη του Τελεστή Ανάθεσης Αντιγράφου\n\n";
	loukas = babis;
	of << "loukas = babis:\n" << loukas << '\n';
	
	of.close();
}

void test_student_overloaded_operators()
{
	Student tmp("0", "tmp");
	assert(tmp.get_current_semester() == 1);

	assert((tmp++).get_current_semester() == 1);
	assert(tmp.get_current_semester() == 2);
	assert((++tmp).get_current_semester() == 3);


	tmp += 2;
	assert(tmp.get_current_semester() == 5);
	tmp -= 4;
	assert(tmp.get_current_semester() == 1);
}
