#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <ostream>

enum class Semester { Winter, Spring };
std::string semester_to_string(const Semester& s);
Semester semester_from_string(const std::string& s);

// Η κλάση "Μάθημα"
class Course {
	// Κωδικός
	std::string code;
	// Λεκτικό
	std::string title;
	// Ώρες ανά εβδομάδα
	unsigned int hrs_per_week;
	// Εξάμηνο Διδασκαλίας (Χειμερινό, Εαρινό)
	Semester semester;
public:
	Course(const std::string& code,
			const std::string& title,
			const unsigned int hrs_per_week,
			Semester semester);
	
	// Copy Constructor, Copy Assignment Operator...

	static Course deserialize_from_csv(const std::string& line);

	virtual ~Course();

	const std::string& get_code() const;
	void set_code(const std::string&);

	const std::string& get_title() const;
	void set_title(const std::string&);

	const unsigned int get_hrs_per_week() const;
	void set_hrs_per_week(const unsigned int);

	const Semester& get_semester() const;
	void set_semester(const Semester&);
};

std::ostream& operator<<(std::ostream& os, const Course& c);
#endif
