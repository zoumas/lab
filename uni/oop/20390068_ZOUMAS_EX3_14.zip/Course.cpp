#include "Course.h"

#include <sstream>
#include <vector>
#include <cassert>

std::string semester_to_string(const Semester& s)
{
	return (s == Semester::Winter) ? std::string("Χειμερινό") : std::string("Εαρινό");
}

Semester semester_from_string(const std::string& s)
{
	return (s == "Χειμερινό") ? Semester::Winter : Semester::Spring;
}

Course::Course(const std::string& code,
		const std::string& title,
		const unsigned int hrs_per_week,
		Semester semester)
: code(code), title(title), hrs_per_week(hrs_per_week), semester(semester)
{
}

// Copy Constructor, Copy Assignment Operator...

Course Course::deserialize_from_csv(const std::string& line)
{
	std::istringstream iss(line);
	std::vector<std::string> tokens;
	std::string token;

	while (std::getline(iss, token, ',')) {
		tokens.push_back(token);
	}

	assert(tokens.size() == 4);

	const std::string code(tokens[0]);
	const std::string title(tokens[1]);
	const unsigned int hrs_per_week(std::stoi(tokens[2]));
	const Semester semester(semester_from_string(tokens[3]));

	return (Course(code, title, hrs_per_week, semester));
}

Course::~Course() {}

const std::string& Course::get_code() const { return code; }
void Course::set_code(const std::string& c) { code = c; }

const std::string& Course::get_title() const { return title; }
void Course::set_title(const std::string& t) { title = t; }

const unsigned int Course::get_hrs_per_week() const
{ return hrs_per_week; }
void Course::set_hrs_per_week(const unsigned int hrs)
{ hrs_per_week = hrs; }

const Semester& Course::get_semester() const { return semester; }
void Course::set_semester(const Semester& s) { semester = s; }

std::ostream& operator<<(std::ostream& os, const Course& c)
{
	os << c.get_code() << ','
	<< c.get_title() << ','
	<< c.get_hrs_per_week() << ','
	<< semester_to_string(c.get_semester());

	return os;
}
