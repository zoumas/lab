#include "Student.h"

#include <cassert>
#include <cstring>
#include <algorithm>
#include <stdexcept>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <iostream>

// Κατασκευή Αντικειμένου
Student::Student(const char* id, 
				const std::string& fullname, 
				const unsigned int current_semester)
: fullname(fullname), current_semester(current_semester)
{
	if (id == nullptr)
		throw std::invalid_argument("Student: id cannot be nullptr");
	// assert(id != nullptr);

	this->id = new char[std::strlen(id) + 1];
	std::strcpy(this->id, id);
}

// Κατασκευαστής Αντιγράφου
Student::Student(const Student& other)
: fullname(other.fullname), current_semester(other.current_semester), 
declared_courses(other.declared_courses), passed_courses(other.passed_courses)
{
	id = new char[std::strlen(other.id) + 1];
	std::strcpy(id, other.id);
}

// Τελεστής Ανάθεσης Αντιγράφου
Student& Student::operator=(const Student& other)
{
	if (this == &other)
		return *this;

	delete[] id;
	id = new char[strlen(other.id) + 1];
	strcpy(id, other.id);

	fullname = other.fullname;
	current_semester = other.current_semester;

	declared_courses = other.declared_courses;
	passed_courses = other.passed_courses;

	return *this;
}

Student* Student::deserialize_from_csv(const std::string& filename)
{
	std::ifstream in(filename);
	if (!in.is_open()) {
		throw std::ios_base::failure("Failed to open file: " + filename);
	}

	std::string line;
	std::getline(in, line, '\n');

	std::vector<std::string> tokens;
	std::string token;
	std::istringstream iss(line);

	while (std::getline(iss, token, ',')) {
		tokens.push_back(token);
	}

	size_t n_tokens(tokens.size());
	assert(n_tokens == 5);

	const char* id(tokens[0].c_str());
	const std::string fullname(tokens[1]);
	const unsigned int current_semester(std::stoi(tokens[2]));

	Student* deserialized(new Student(id, fullname, current_semester));
	
	const size_t n_declared(std::stoi(tokens[3]));
	const size_t n_passed(std::stoi(tokens[4]));

	for (size_t i = 0; i < n_declared; ++i) {
		std::getline(in, line, '\n');
		deserialized->add_declared_course(std::make_shared<Course>(Course::deserialize_from_csv(line)));
	}

	for (size_t i = 0; i < n_passed; ++i) {
		std::getline(in, line, '\n');

		size_t last_comma_pos(line.rfind(','));
		// Extract the Grade
		std::string grade_str(line.substr(last_comma_pos + 1));

		// Extract the Course
		std::string course_str(line.substr(0, last_comma_pos));

		std::shared_ptr<Course> c(std::make_shared<Course>(Course::deserialize_from_csv(course_str)));
		const float grade(std::stof(grade_str));

		deserialized->add_passed_course(c, grade);
	}

	if (in.bad()) {
		throw std::ios_base::failure("Error reading from the file: " + filename);
	}

	return deserialized;
}

// Καταστροφή Αντικειμένου
// Εικονικός Καταστροφέας
Student::~Student()
{
	delete[] id;
}

// Accessors (Getters - Setters)
const char* Student::get_id() const { return id; }
void Student::set_id(const char* id)
{
	if (id == nullptr) {
		throw std::invalid_argument("set_id: id cannot be nullptr");
	}
	// assert(id != nullptr);

	delete[] this->id;
	this->id = new char[std::strlen(id) + 1];
	std::strcpy(this->id, id);
}

const std::string& Student::get_fullname() const { return fullname; }
void Student::set_fullname(const std::string& n) { fullname = n; }

const unsigned int Student::get_current_semester() const
{ return current_semester; }
void Student::set_current_semester(const unsigned int cs)
{ current_semester = cs; }

const std::vector<std::shared_ptr<Course>>& Student::get_declared_courses() const
{ return declared_courses; }

const std::unordered_map<std::shared_ptr<Course>, float>& Student::get_passed_courses() const
{ return passed_courses; }

// Λειτουργίες
void Student::add_declared_course(std::shared_ptr<Course> c)
{
	auto it(std::find(declared_courses.begin(), declared_courses.end(), c));
	// Πρόσθεσε το μάθημα μόνο αν δεν είναι ήδη
	// δηλωμένο
	if (it == declared_courses.end())
		declared_courses.push_back(c);
}

void Student::add_passed_course(std::shared_ptr<Course> c, float grade)
{
	passed_courses.insert_or_assign(c, grade);
}

float Student::average_grade() const
{
	size_t count(0);
	float sum(0.0f);

	for (const auto& [_, grade] : passed_courses) {
		++count;
		sum += grade;
	}

	return (count > 0) ? sum / static_cast<float>(count) : 0.0f;
}

// Επιστρέφει το πλήθος των δηλωμένων μαθημάτων
size_t Student::declared() const { return declared_courses.size(); }
// Επιστρέφει το πλήθος των περασμένων μαθημάτων
size_t Student::passed() const { return passed_courses.size(); }

void Student::serialize_to_csv(const std::string& filename)
{
	std::ofstream out(filename);
	if (!out.is_open()) {
		throw std::ios_base::failure("Failed to open file: " + filename);
	}

	out << id << ','
	<< fullname << ','
	<< current_semester;

	size_t num_declared(declared());	
	size_t num_passed(passed());
	
	out << ',' << num_declared;

	out << ',' << num_passed;

	for (const auto& c : declared_courses) {
		out << '\n' << *c;
	}

	for (const auto& [c, grade] : passed_courses) {
		out << '\n' << *c << ',' << grade;
	}

	if (out.bad()) {
		throw std::ios_base::failure("Error writing to the file: " + filename);
	}

	out.close();
}

// Τελεστές
Student& Student::operator++()
{
	++current_semester;
	return *this;
}

Student Student::operator++(int)
{
	Student tmp(*this);
	++current_semester;
	return tmp;
}

Student& Student::operator+=(const unsigned int semester_incr)
{
	current_semester += semester_incr;
	return *this;
}

Student& Student::operator-=(const unsigned int semester_decr)
{
	current_semester -= semester_decr;
	return *this;
}

Student& Student::operator+=(std::shared_ptr<Course> course_to_be_declared)
{
	add_declared_course(course_to_be_declared);
	return *this;
}

bool Student::operator==(const Student& other) { return current_semester == other.current_semester; }
bool Student::operator!=(const Student& other) { return current_semester != other.current_semester; }
bool Student::operator<(const Student& other) { return current_semester < other.current_semester; }
bool Student::operator<=(const Student& other) { return current_semester <= other.current_semester; }
bool Student::operator>(const Student& other) { return current_semester > other.current_semester; }
bool Student::operator>=(const Student& other) { return current_semester >= other.current_semester; }

std::ostream& operator<<(std::ostream& os, const Student& s)
{
	os << "Αριθμός Μητρώου: " << s.get_id() << '\n'
	   << "Ονοματεπώνυμο: " << s.get_fullname() << '\n'
	   << "Τρέχον Εξάμηνο: " << s.get_current_semester();

	auto declared(s.get_declared_courses());
	if (declared.size() > 0) {
		os << '\n' << "Δηλωμένα Μαθήματα:";
		for (const auto& c : declared) {
			os << "\n " << c->get_title();
		}
	}

	auto passed(s.get_passed_courses());
	if (passed.size() > 0) {
		os << '\n' << "Περασμένα Μαθήματα:";
		for (const auto& [c, grade] : passed) {
			os << "\n " << c->get_title() << " : " << grade;
		}

		os << "\nΜέσος Όρος: " << s.average_grade();
	}

	return os;
}
