#ifndef STUDENT_H
#define STUDENT_H

#include "Course.h"

#include <string>
#include <ostream>
#include <vector>
#include <unordered_map>
#include <memory>

// Η κλάση "Φοιτητής".
class Student {
	// ΑΜ
	char* id;
	// Ονοματεπώνυμο
	std::string fullname;
	// Τρέχον εξάμηνο
	unsigned int current_semester;
	// Τα δηλωμένα μαθήματα του τρέχοντος εξαμήνου 
	std::vector<std::shared_ptr<Course>> declared_courses;
	// Οι βαθμοί των επιτυχώς ολοκληρωμένων μαθημάτων προηγούμενων εξαμήνων
	std::unordered_map<std::shared_ptr<Course>, float> passed_courses;
public:
// Κατασκευή Αντικειμένου
	Student(const char* id, 
			const std::string& fullname, 
			const unsigned int current_semester = 1);
	// Κατασκευαστής Αντιγράφου
	Student(const Student& other);
	// Τελεστής Ανάθεσης Αντιγράφου
	Student& operator=(const Student& other);

	static Student* deserialize_from_csv(const std::string& filename);

// Καταστροφή Αντικειμένου
	// Εικονικός Καταστροφέας
	virtual ~Student();

// Accessors (Getters - Setters)
	const char* get_id() const;
	void set_id(const char*);

	const std::string& get_fullname() const;
	void set_fullname(const std::string&);

	const unsigned int get_current_semester() const;
	void set_current_semester(const unsigned int);

	const std::vector<std::shared_ptr<Course>>& get_declared_courses() const;
	const std::unordered_map<std::shared_ptr<Course>, float>& get_passed_courses() const;

// Λειτουργίες
	void add_declared_course(std::shared_ptr<Course>);
	void add_passed_course(std::shared_ptr<Course>, float grade);

	// Μέσος Όρος του Φοιτητή
	float average_grade() const;

	// Επιστρέφει το πλήθος των δηλωμένων μαθημάτων
	size_t declared() const;
	// Επιστρέφει το πλήθος των περασμένων μαθημάτων
	size_t passed() const;

	void serialize_to_csv(const std::string& filename);

// Τελεστές
	// Αύξηση του τρέχοντος εξαμήνου κατά 1 με χρήση του τελεστή προαύξησης ή του τελεστή μετααύξησης
	Student& operator++();
	Student operator++(int);

	// Αλλαγή του εξαμήνου με την χρήση των τελεστών “+=” και “-=”
	Student& operator+=(const unsigned int semester_incr);
	Student& operator-=(const unsigned int semester_decr);

	// Υπερφορτώστε τον τελεστή ‘+=’ ώστε να προσθέτει ένα μάθημα στο σύνολο των δηλωμένων μαθημάτων.
	Student& operator+=(std::shared_ptr<Course> course_to_be_declared);

	// Υπεροφρτώστε τους τελεστές “==”, “!=”, “<”, “<=”, “>”, “>=”.  Η σύγκριση θα αφορά το εξάμηνο του φοιτητή
	bool operator==(const Student& other);
	bool operator!=(const Student& other);
	bool operator<(const Student& other);
	bool operator<=(const Student& other);
	bool operator>(const Student& other);
	bool operator>=(const Student& other);
};


// Υπερφορτώστε ό,τι χρειάζεται, ώστε η εντολή: C1 << S1; 
// (όπου C1 στιγμιότυπο της κλάσης “ostream” και S1 στιγμιότυπο της κλάσης Φοιτητής) 
// να τυπώνει την αναλυτική βαθμολογία του φοιτητή στο κανάλι. Στην αναλυτική θα αναγράφεται και ο μέσος όρος του φοιτητή.
std::ostream& operator<<(std::ostream& os, const Student& s);

#endif
